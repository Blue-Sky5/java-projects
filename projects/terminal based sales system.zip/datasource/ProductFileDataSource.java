package datasource;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ProductFileDataSource implements ProductDataSource{
    @Override
    public List<Product> getProducts(int n) {
        String[] temp;
        List<Product> out = new ArrayList<>();
        File in = new File("src/File.txt");
        try {
            Scanner file_in = new Scanner(in);
            while (file_in.hasNextLine()){
                temp = file_in.nextLine().split(" ");
                out.add(new Product(temp));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.out.println("Couldn't open the file");
        }
        while (n<out.size()){
            out.remove(0);
        }
        return out;
    }

    @Override
    public Product getProduct() {
        Product out;
        String[] temp = {};
        File in = new File("src/File.txt");
        try {
            Scanner file_in = new Scanner(in);
            while (file_in.hasNextLine()){
                temp = file_in.nextLine().split(" ");
            }
            out = new Product(temp);
            return out;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.out.println("Couldn't open the file");
        }
        return null;
    }

    @Override
    public void saveProducts(List<Product> products) {
        File out = new File("src/File.txt");
        if(!out.exists()){
            try {
                out.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("couldn't create the file");
            }
        }
        try {
            BufferedWriter appends = new BufferedWriter(new FileWriter("src/File.txt",true));
            for (Product product : products) {
                appends.write(product.id+" "+product.name+" "+product.price+" "+product.number+"\n");
            }
            appends.close();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("couldn't append the product ");
        }
    }

    @Override
    public void saveProduct(Product product)  {
        File out = new File("src/File.txt");
        if(!out.exists()){
            try {
                out.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("couldn't create the file");
            }
        }
        try {
            BufferedWriter appends = new BufferedWriter(new FileWriter("src/File.txt",true));
            appends.write(product.id+" "+product.name+" "+product.price+" "+product.number+"\n");
            appends.close();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("couldn't append the product ");
        }
    }
}
