package datasource;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ProductInputDataSource implements ProductDataSource{
    @Override
    public List<Product> getProducts(int n){
        List<Product> in = new ArrayList<>();
        Scanner inp = new Scanner(System.in);
        for (int i = 0 ; i < n ; i++){
            in.add(new Product(inp.nextLine().split(" ")));
        }
        return in;
    }

    @Override
    public Product getProduct() {
        Scanner in = new Scanner(System.in);
        return new Product(in.nextLine().split(" "));
    }

    @Override
    public void saveProducts(List<Product> products) {
        for (Product product : products) {
            product.print();
        }
    }

    @Override
    public void saveProduct(Product product) {
        product.print();
    }
}
