package datasource;
import java.util.List;

public interface SaleDataSource {
    List<Sale> getSales(int n);
    Sale getSale();
    void saveSales(List<Sale> sales);
    void saveSale(Sale sale);
}
