package datasource;
public class Sale {
    int id;
    int number;
    String date;
    public Sale(String[] a){
        this.id = Integer.parseInt(a[0]);
        this.number = Integer.parseInt(a[1]);
        this.date = a[2];

    }
    public Sale(){

    }
    public void print(){
        System.out.println(this.id+" "+this.number+" "+this.date);
    }
}

