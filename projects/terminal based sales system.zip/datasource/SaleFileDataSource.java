package datasource;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SaleFileDataSource implements SaleDataSource{
    @Override
    public List<Sale> getSales(int n) {
        String[] temp;
        List<Sale> out = new ArrayList<>();
        File in = new File("src/File2.txt");
        try {
            Scanner file_in = new Scanner(in);
            while (file_in.hasNextLine()){
                temp = file_in.nextLine().split(" ");
                out.add(new Sale(temp));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.out.println("Couldn't open the file");
        }
        while (n<out.size()){
            out.remove(0);
        }
        return out;
    }

    @Override
    public Sale getSale() {
        Sale out;
        String[] temp = {};
        File in = new File("src/File2.txt");
        try {
            Scanner file_in = new Scanner(in);
            while (file_in.hasNextLine()){
                temp = file_in.nextLine().split(" ");
            }
            out = new Sale(temp);
            return out;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.out.println("Couldn't open the file");
        }
        return null;
    }

    @Override
    public void saveSales(List<Sale> sales) {
        File out = new File("src/File2.txt");
        if(!out.exists()){
            try {
                out.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("couldn't create the file");
            }
        }
        try {
            BufferedWriter appends = new BufferedWriter(new FileWriter("src/File2.txt",true));
            for (Sale sale : sales) {
                appends.write(sale.id+" "+sale.number+" "+sale.date+"\n");
            }
            appends.close();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("couldn't append the sale ");
        }
    }

    @Override
    public void saveSale(Sale sale) {
        File out = new File("src/File2.txt");
        if(!out.exists()){
            try {
                out.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("couldn't create the file");
            }
        }
        try {
            BufferedWriter appends = new BufferedWriter(new FileWriter("src/File2.txt",true));
            appends.write(sale.id+" "+sale.number+" "+sale.date+"\n");
            appends.close();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("couldn't append the sale ");
        }
    }
}
