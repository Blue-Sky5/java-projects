package datasource;
public class Repository {

    private ProductDataSource productInputDataSource = new ProductInputDataSource();
    private ProductDataSource productFileDataSource = new ProductFileDataSource();
    private SaleDataSource saleInputDataSource = new SaleInputDataSource();
    private SaleDataSource saleFileDataSource = new SaleFileDataSource();

    public Repository() {
        productInputDataSource = new ProductInputDataSource();
        productFileDataSource = new ProductFileDataSource();
        saleInputDataSource = new SaleInputDataSource();
        saleFileDataSource = new SaleFileDataSource();
    }

    public void saveProduct() {
        productFileDataSource.saveProduct(productInputDataSource.getProduct());
    }

    public void saveProducts(int n) {
        productFileDataSource.saveProducts(productInputDataSource.getProducts(n));
    }

    public void saveSale() {
        saleFileDataSource.saveSale(saleInputDataSource.getSale());
    }

    public void saveSales(int n) {
        saleFileDataSource.saveSales(saleInputDataSource.getSales(n));
    }

    public void printProduct() {
        productInputDataSource.saveProduct(productFileDataSource.getProduct());
    }

    public void printProducts(int n) {
        productInputDataSource.saveProducts(productFileDataSource.getProducts(n));
    }

    public void printSale() {
        saleInputDataSource.saveSale(saleFileDataSource.getSale());
    }

    public void printSales(int n) {
        saleInputDataSource.saveSales(saleFileDataSource.getSales(n));
    }
}
