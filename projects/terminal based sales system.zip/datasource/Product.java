package datasource;

public class Product {
    int id;
    String name;
    int price;
    int number;
    public Product(String[] a){
        this.id = Integer.parseInt(a[0]);
        this.name = a[1];
        this.price = Integer.parseInt(a[2]);
        this.number = Integer.parseInt(a[3]);
    }
    public Product(){

    }
    public void print(){
        System.out.println(this.id+" "+this.name+" "+this.price+" "+this.number);
    }

}
