package datasource;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SaleInputDataSource implements SaleDataSource {
    @Override
    public List<Sale> getSales(int n) {
        List<Sale> in = new ArrayList<>();
        Scanner inp = new Scanner(System.in);
        for (int i = 0 ; i < n ; i++){
            in.add(new Sale(inp.nextLine().split(" ")));
        }
        return in;
    }

    @Override
    public Sale getSale() {
        Scanner in = new Scanner(System.in);
        return new Sale(in.nextLine().split(" "));
    }

    @Override
    public void saveSales(List<Sale> sales) {
        for (Sale sale : sales) {
            sale.print();
        }
    }

    @Override
    public void saveSale(Sale sale) {
        sale.print();
    }
}
