package datasource;

import java.util.List;

public interface ProductDataSource {
    List<Product> getProducts(int n);
    Product getProduct();
    void saveProducts(List<Product> products);
    void saveProduct(Product product);
}
