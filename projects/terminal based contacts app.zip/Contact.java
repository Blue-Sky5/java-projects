public class Contact {
    public Contact(String name,String LastName,String phoneNumber,String email){
        setEmail(email);
        setLastname(LastName);
        setPhoneNumber(phoneNumber);
        setName(name);
    }
    private String name ;
    private String lastname;
    private String email;
    private String phoneNumber;
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getLastName() {
        return lastname;
    }
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
