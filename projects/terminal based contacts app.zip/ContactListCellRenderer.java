import javax.swing.*;
import java.awt.*;

public class ContactListCellRenderer extends JPanel implements ListCellRenderer<Contact> {
    @Override
    public Component getListCellRendererComponent(JList<? extends Contact> list, Contact value, int index, boolean isSelected, boolean cellHasFocus) {
        JContact jContact = new JContact();
        jContact.setName(value.getName());
        jContact.setLastName(value.getLastName());
        jContact.setPhoneNumber(value.getPhoneNumber());
        jContact.setEmail(value.getEmail());
        return jContact;
    }
}