import javax.swing.*;
import java.awt.*;

public class JContact extends JComponent {

    JLabel name_label = new JLabel();
    JLabel lastname_label = new JLabel();
    JLabel phonenumber_label = new JLabel();
    JLabel email_label = new JLabel();
    JLabel blank = new JLabel("blank");
    public JContact(){
        //i honestly couldn't figure it out why phone and email label are no match hto their names even when the code is right lol
        setLayout(new GridLayout(4,2));
        setBackground(Color.BLACK);
        setOpaque(true);
        name_label.setBackground(new Color(217,237,146));
        name_label.setOpaque(true);
        lastname_label.setBackground(new Color(217,237,146));
        lastname_label.setOpaque(true);
        add(name_label);
        add(lastname_label);
        add(email_label);
        add(new JLabel("  "));
        add(phonenumber_label);
        add(new JLabel("  "));
        add(new JLabel("----------------------"));

    }
    public void setName(String name) {
        name_label.setText(name);
    }
    public void setLastName(String lastName) {
        lastname_label.setText(lastName);
    }
    public void setPhoneNumber(String phoneNumber) {
        phonenumber_label.setText(phoneNumber);
    }
    public void setEmail(String email) {
        email_label.setText(email);
    }
}
