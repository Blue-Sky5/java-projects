import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setSize(500, 500);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setVisible(true);

        frame.setLayout(new BorderLayout());
        Contact contact1 = new Contact("ali", "ahmadi", "a@gmail.com", "0912313");
        Contact contact2 = new Contact("bita", "mahdavi", "b@gmail.com", "098776432");
        Contact contact3 = new Contact("reza", "rezvini", "r@u", "0234525");
        Contact contact4 = new Contact("mamad", "milai", "f@a", "5215");
        Contact contact5 = new Contact("mojtaba", "kiani", "g@l", "1253235");
        Contact contact6 = new Contact("anahita", "khosravi", "ji@j", "12352");
        DefaultListModel<Contact> model = new DefaultListModel<>();
        model.addElement(contact1);
        model.addElement(contact2);
        model.addElement(contact3);
        model.addElement(contact4);
        model.addElement(contact5);
        model.addElement(contact6);
        model.addElement(contact1);
        model.addElement(contact2);
        model.addElement(contact3);
        model.addElement(contact4);
        model.addElement(contact5);
        model.addElement(contact6);
        JList<Contact> contactJList = new JList<>(model);
        contactJList.setCellRenderer(new ContactListCellRenderer());

        frame.add(new JScrollPane(contactJList));
        frame.validate();
    }
}