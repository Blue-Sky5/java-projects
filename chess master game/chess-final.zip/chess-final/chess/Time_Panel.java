package chess;


import javax.swing.*;
import java.awt.*;

class Time_Panel{
    JPanel time;
    public Time_Panel(){
        time = new JPanel();
        Image background = Toolkit.getDefaultToolkit().createImage("C:\\Users\\amn_n\\Pictures\\one.png");
        //time.imageUpdate(background);
    }
}