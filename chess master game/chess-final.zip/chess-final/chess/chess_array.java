package chess;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Scanner;

public class chess_array {
    public static int[][] chess_array = {{-3,-5,-4,-1,-2,-4,-5,-3},{-6,-6,-6,-6,-6,-6,-6,-6},
            {0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0}
            ,{0,0,0,0,0,0,0,0},{6,6,6,6,6,6,6,6},{3,5,4,1,2,4,5,3}};
    public static void Restart_Board(){
        chess_array = new int[][]{{-3, -5, -4, -1, -2, -4, -5, -3}, {-6, -6, -6, -6, -6, -6, -6, -6},
                {0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0}
                , {0, 0, 0, 0, 0, 0, 0, 0}, {6, 6, 6, 6, 6, 6, 6, 6}, {3, 5, 4, 1, 2, 4, 5, 3}};
    }
    public static boolean Save(Board_UI board_ui){
        update(board_ui);
        try {
            PrintStream myWriter = new PrintStream("src/chess/Files/Board_Save.txt");
            for(int i = 0 ; i < 8 ; i++){
                for (int j = 0 ; j < 8 ; j++){
                    myWriter.print(chess_array[i][j]+" ");
                }
                myWriter.println("\n");
            }
            myWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }
    public static void update(Board_UI a){
        for(int i = 0 ; i < 8 ; i++){
            for (int j = 0 ; j < 8 ; j++) {
                if(a.board_tiles[i][j].piece == null){
                    chess_array[i][j] = 0;
                }
                else {
                    chess_array[i][j] = a.board_tiles[i][j].piece.getValue();
                }
            }
        }
    }
    public static void Move(tiles[][] a) {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (a[i][j].piece == null) {
                    chess_array[i][j] = 0;
                } else {
                    chess_array[i][j] = a[i][j].piece.getValue();
                }
            }
        }
    }
    public static boolean load(){
        File load = new File("src/chess/Files/Board_Save.txt");
        String[] line;
        try {
            int i = 0;
            Scanner input = new Scanner(load);
            while (input.hasNextLine()){
                line = input.nextLine().split(" ");
                if(line.length == 8){
                    for(int j  =0 ; j < 8 ; j++){
                        chess_array[i][j] = Integer.parseInt(line[j]);
                    }
                    i+=1;
                }
            }
//            for(int i = 0 ; i < 8 ; i++) {
//                line = input.nextLine().split("");
//                for (int j = 0; j < 8; j++) {
//                    chess_array[i][j] = Integer.parseInt(line[j]);
//                }
//            }
            return true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        }

    }
}
