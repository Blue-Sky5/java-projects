package chess;

public class queen extends chess_piece{
    public queen(int x){
        if(x>0){
            setValue(this.value);
            setIcon_address(icon_address_w);
        }
        else {
            this.value*=-1;
            setValue(this.value);
            setIcon_address(icon_address_b);
        }
    }

    @Override
    public boolean is_valid_move(int x1, int y1, int x2, int y2, tiles[][] board_game) {
        int cumulate = 0;
        //rook moves
        if(rook.is_valid_move_s(x1, y1, x2, y2, board_game)){
            cumulate+=1;
        }
        if(bishop.is_valid_move_s(x1, y1, x2, y2, board_game)){
            cumulate+=1;
        }
        return cumulate == 1;
    }

    public int value = 2;
    public static String icon_address_w = "src/chess/Pieces PNG/white_queen.png";
    public static String icon_address_b = "src/chess/Pieces PNG/black_queen.png";
    public String icon_address;
}
