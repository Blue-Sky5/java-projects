package chess;

import javax.swing.*;

public class tiles extends JButton {
    public int x_cord;
    public int y_cord;
    public tiles(){
        super();
    }
    public chess_piece piece;
}
