package chess;

public class knight extends chess_piece {
    public knight(int x){
        if(x>0){
            setValue(this.value);
            setIcon_address(icon_address_w);
        }
        else {
            this.value*=-1;
            setValue(this.value);
            setIcon_address(icon_address_b);
        }
    }

    @Override
    public boolean is_valid_move(int x1, int y1, int x2, int y2, tiles[][] board_game) {
        if((y1+2 == y2||y1-2 == y2) && (x1+1 == x2 || x1-1 == x2)&& (board_game[x2][y2].piece == null || this.getValue() * board_game[x2][y2].piece.getValue() <0 )){
            return true;
        }
        else if((y1+1 == y2||y1-1 == y2) && (x1+2 == x2 || x1-2 == x2)&& (board_game[x2][y2].piece == null || this.getValue() * board_game[x2][y2].piece.getValue() <0 )){
            return true;
        }
        else {
            return false;
        }

    }
    public int value = 5;
    public static String icon_address_w = "src/chess/Pieces PNG/white_knight.png";
    public static String icon_address_b = "src/chess/Pieces PNG/black_knight.png";
    public static String icon_address;
}
