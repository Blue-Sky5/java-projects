package chess;
import java.lang.Math;

public class king extends chess_piece{
    public king(int x){
        if(x>0){
            setValue(this.value);
            setIcon_address(icon_address_w);
        }
        else {
            this.value*=-1;
            setValue(this.value);
            setIcon_address(icon_address_b);
        }
    }

    @Override
    public boolean is_valid_move(int x1, int y1, int x2, int y2, tiles[][] board_game) {
        if(x1==x2 && y2==y1){
            return false;
        }
        else {
            if((int)Math.abs(x1-x2)<=1 && (int)Math.abs(y1-y2)<=1){
                if(board_game[x2][y2].piece!= null && board_game[x2][y2].piece.getValue() * this.getValue() > 0){
                    return false;
                }
                else {
                    return true;
                }
            }
            else {
                return false;
            }
        }
    }

    public int value = 1;
    public static String icon_address_w = "src/chess/Pieces PNG/white_king.png";
    public static String icon_address_b = "src/chess/Pieces PNG/black_king.png";
    public String icon_address;
}
