package chess;

import javax.swing.*;
import java.awt.*;

import static javax.swing.JOptionPane.showMessageDialog;

public class Operator {
    public static int x1_cord = -10;
    public static int y1_cord = -10;
    public static int x2_cord = -10;
    public static int y2_cord = -10;
    public static Color color;
    public static boolean White_Turn = true;
    public static boolean AI = true;
    public static void input(int x, int y, tiles[][] board_tiles, chess_history game_history) {
        //sweep the changes
        if (x1_cord == -10 && board_tiles[x][y].piece != null && correct_turn(Operator.White_Turn, board_tiles[x][y].piece.getValue())) {
            x1_cord = x;
            y1_cord = y;
            board_tiles[x1_cord][y1_cord].setBorder(BorderFactory.createLineBorder(Color.RED, 1));
        } else if (x1_cord != -10) {
            x2_cord = x;
            y2_cord = y;
            board_tiles[x2_cord][y2_cord].setBorder(BorderFactory.createLineBorder(Color.RED, 1));
            if (board_tiles[x1_cord][y1_cord].piece.is_valid_move(x1_cord, y1_cord, x2_cord, y2_cord, board_tiles)) {
                game_history.add(board_tiles[x1_cord][y1_cord].piece.getValue(), x1_cord, y1_cord, x2_cord, y2_cord);
                if (board_tiles[x2_cord][y2_cord].piece != null) {
                    game_history.add2(chess_piece.Piece_Name_return(board_tiles[x2_cord][y2_cord].piece.getValue()), board_tiles[x2_cord][y2_cord].piece.getValue() > 0);
                    if (board_tiles[x2_cord][y2_cord].piece.getValue() == 1) {
                        showMessageDialog(null, "Game Has Ended! ,Player Black Won");
                        game_history.game_history.setText("--Game Has Ended! ,Player Black Won--");
                    } else if (board_tiles[x2_cord][y2_cord].piece.getValue() == -1) {
                        showMessageDialog(null, "Game Has Ended! ,Player White Won");
                        game_history.game_history.setText("--Game Has Ended! ,Player White Won--");
                    }
                }
                White_Turn = !White_Turn;
                board_tiles[x2_cord][y2_cord].piece = board_tiles[x1_cord][y1_cord].piece;
                board_tiles[x1_cord][y1_cord].piece = null;
                board_tiles[x2_cord][y2_cord].setIcon(new ImageIcon(board_tiles[x2_cord][y2_cord].piece.getIcon_address()));
                board_tiles[x1_cord][y1_cord].setIcon(null);
            } else {
                showMessageDialog(null, "invalid move!");
                System.out.println("invalid move!");
            }
            if (x1_cord != -10 && x2_cord != -10) {
                board_tiles[x1_cord][y1_cord].setBorder(BorderFactory.createLineBorder(board_tiles[x2_cord][y2_cord].getBackground(), 1));
                board_tiles[x2_cord][y2_cord].setBorder(BorderFactory.createLineBorder(board_tiles[x2_cord][y2_cord].getBackground(), 1));
                x1_cord = -10;
                y1_cord = -10;
                x2_cord = -10;
                y2_cord = -10;
            }
        } else {
            showMessageDialog(null, "Not Your Turn or empty tile");
            System.out.println("invalid move or empty tile");
        }

    }

    public static boolean correct_turn(boolean white_Turn, int piece) {
        if (white_Turn && piece > 0) {
            return true;
        } else if (!white_Turn && piece < 0) {
            return true;
        } else {
            return false;
        }
    }
}
