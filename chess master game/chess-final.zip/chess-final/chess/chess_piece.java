package chess;

public class chess_piece {
    public chess_piece(){

    }
    public boolean is_valid_move(int x1,int y1,int x, int y, tiles[][] board_game){
        return true;
    };
    private int value = 10;
    private String icon_address;

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getIcon_address() {
        return icon_address;
    }

    public void setIcon_address(String icon_address) {
        this.icon_address = icon_address;
    }
    public static String Piece_Name_return(int a){
        String[] pattern = {"Queen","King","Rook","Bishop","Knight","Pawn"};
        a = Math.abs(a) - 1;
        return pattern[a];
    }
}
