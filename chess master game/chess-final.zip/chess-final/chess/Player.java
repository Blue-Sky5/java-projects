package chess;

import java.util.List;

public interface Player {

    int[][] nextMove(int[][] positions, boolean white);
}
