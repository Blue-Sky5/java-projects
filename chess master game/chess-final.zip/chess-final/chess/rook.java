package chess;

public class rook extends chess_piece{
    public rook(int x){
        if(x>0){
            setValue(this.value);
            setIcon_address(icon_address_w);
        }
        else {
            this.value*=-1;
            setValue(this.value);
            setIcon_address(icon_address_b);
        }
    }

    @Override
    public boolean is_valid_move(int x1, int y1, int x2, int y2, tiles[][] board_game) {
        boolean is_clean = true;
            if (y2 == y1 && x1!=x2){
                if(x1 > x2){
                    for(int i = x2; i < x1 ; i++){
                        if(board_game[i][y1].piece != null && board_game[i][y1].piece.getValue() * this.getValue() > 0){
                            is_clean = false;
                        }
                    }
                }
                else {
                    for(int i = x1+1; i <= x2 ; i++){
                        if(board_game[i][y1].piece != null && board_game[i][y1].piece.getValue() * this.getValue() > 0){
                            is_clean = false;
                        }
                    }
                }

                return is_clean;
            }
            else if(y2 != y1 && x1== x2){
                if(y1 >y2){
                    for(int i = y2; i < y1 ; i++){
                        if(board_game[x1][i].piece != null && board_game[x1][i].piece.getValue() * this.getValue() > 0){
                            is_clean = false;
                        }
                    }
                }
                else {
                    for(int i = y1+1; i <= y2 ; i++){
                        if(board_game[x1][i].piece != null && board_game[x1][i].piece.getValue() * this.getValue() > 0){
                            is_clean = false;
                        }
                    }
                }

                return is_clean;
            }
            else {
                return false;
            }

    }
    public static boolean is_valid_move_s(int x1, int y1, int x2, int y2, tiles[][] board_game) {
        boolean is_clean = true;
        if (y2 == y1 && x1!=x2){
            if(x1 > x2){
                for(int i = x2; i < x1 ; i++){
                    if(board_game[i][y1].piece != null && board_game[i][y1].piece.getValue() * board_game[x1][y1].piece.getValue() > 0){
                        is_clean = false;
                    }
                }
            }
            else {
                for(int i = x1+1; i <= x2 ; i++){
                    if(board_game[i][y1].piece != null && board_game[i][y1].piece.getValue() * board_game[x1][y1].piece.getValue() > 0){
                        is_clean = false;
                    }
                }
            }

            return is_clean;
        }
        else if(y2 != y1 && x1== x2){
            if(y1 >y2){
                for(int i = y2; i < y1 ; i++){
                    if(board_game[x1][i].piece != null && board_game[x1][i].piece.getValue() * board_game[x1][y1].piece.getValue() > 0){
                        is_clean = false;
                    }
                }
            }
            else {
                for(int i = y1+1; i <= y2 ; i++){
                    if(board_game[x1][i].piece != null && board_game[x1][i].piece.getValue() * board_game[x1][y1].piece.getValue() > 0){
                        is_clean = false;
                    }
                }
            }

            return is_clean;
        }
        else {
            return false;
        }

    }
    public int value = 3 ;
    public static String icon_address_w = "src/chess/Pieces PNG/white_rook.png";
    public static String icon_address_b = "src/chess/Pieces PNG/black_rook.png";
    public String icon_address;
}
