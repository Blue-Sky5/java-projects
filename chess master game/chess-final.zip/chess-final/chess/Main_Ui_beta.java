package chess;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

import static javax.swing.JOptionPane.showMessageDialog;

public class Main_Ui_beta {
    public static Board_UI board_ui;
    public static void main(String[] args){
        JFrame Main_Chess_Window = new JFrame("Cool_Chess V 2.0");
        Main_Chess_Window.setSize(900 ,600);
        Main_Chess_Window.setResizable(false);
        Main_Chess_Window.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        SpringLayout Main_layout = new SpringLayout();
        Container panel = Main_Chess_Window.getContentPane();
        //..................icon & etc.....................
        ImageIcon frame_icon = new ImageIcon("src/chess/Files/one.jpg");
        Main_Chess_Window.setIconImage(frame_icon.getImage());
        //.................................................
        board_ui = new Board_UI();
        JPanel right = new JPanel();
        right.setBackground(Color.green);
        JPanel up = new JPanel();
        up.setBackground(Color.BLACK);
        chess_history history = new chess_history();
        board_ui.set_game_history(history);
        //..............................//button_panel//........................................
        GridLayout button_command_layout = new GridLayout(3,1);
        JButton Restart = new JButton("Restart");
        Restart.setBorder(new LineBorder(Color.BLACK));
        Restart.setBackground(new Color(253,255,182));
        Restart.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                board_ui.board_restart();
                history.restart();
            }
        });
        JButton Load = new JButton("Load");
        Load.setBorder(new LineBorder(Color.BLACK));
        Load.setBackground(new Color(253,255,182));
        Load.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //...............game history load .............
                File load = new File("src/chess/Files/Game_history.txt");
                try {
                    Scanner in = new Scanner(load);
                    history.game_history.setText(null);
                    while (in.hasNextLine()){
                        history.game_history.append(in.nextLine());
                        history.game_history.append("\n");
                    }
                } catch (FileNotFoundException ex) {
                    ex.printStackTrace();
                }
                //............................................\\
                boolean a ;
                a = board_ui.load_board();
                if(a){
                    showMessageDialog(null, "Successfully Loaded");
                }
                else {
                    showMessageDialog(null, "Problem while trying to load");
                }
            }
        });
        JButton Save = new JButton("save");
        Save.setBorder(new LineBorder(Color.BLACK));
        Save.setBackground(new Color(253,255,182));
        Save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean a = chess_array.Save(board_ui);
                //..........Save history....................
                try {
                    PrintStream myWriter = new PrintStream("src/chess/Files/Game_history.txt");
                    myWriter.println(history.game_history.getText());
                } catch (FileNotFoundException ex) {
                    ex.printStackTrace();
                }
                //.........................................\\
                if (a){
                    showMessageDialog(null, "Successfully Saved");
                }
                else {
                    showMessageDialog(null, "An Error occured while saving the game");
                }
            }
        });
        JPanel button_command = new JPanel();
        button_command.setLayout(button_command_layout);
        button_command.add(Restart);
        button_command.add(Save);
        button_command.add(Load);
        //......................................................................................
        Main_Chess_Window.add(right);
        Main_Chess_Window.add(board_ui.main_panel);
        Main_Chess_Window.setLayout(Main_layout);
        Main_layout.putConstraint(SpringLayout.NORTH, board_ui.main_panel, 0, SpringLayout.NORTH, panel);
        Main_layout.putConstraint(SpringLayout.SOUTH, board_ui.main_panel, 0, SpringLayout.SOUTH, panel);
        Main_layout.putConstraint(SpringLayout.EAST, board_ui.main_panel, 0, SpringLayout.WEST, right);
        Main_layout.putConstraint(SpringLayout.WEST,board_ui.main_panel, 0, SpringLayout.WEST, panel);
        Main_layout.putConstraint(SpringLayout.NORTH, right, 0, SpringLayout.NORTH,panel);
        Main_layout.putConstraint(SpringLayout.SOUTH, right, 0, SpringLayout.SOUTH,panel);
        Main_layout.putConstraint(SpringLayout.EAST, right, 0, SpringLayout.EAST,panel);
        Main_layout.putConstraint(SpringLayout.WEST, right, 600, SpringLayout.WEST,panel);
        Main_layout.putConstraint(SpringLayout.VERTICAL_CENTER, board_ui.main_panel, 0, SpringLayout.VERTICAL_CENTER, right);
        //............................................................
        SpringLayout Right_layout = new SpringLayout();
        right.add(up);
        right.add(button_command);
        right.add(history.history_panel);
        Right_layout.putConstraint(SpringLayout.NORTH, up, 0, SpringLayout.NORTH, right);
        Right_layout.putConstraint(SpringLayout.EAST, up, 0, SpringLayout.EAST, right);
        Right_layout.putConstraint(SpringLayout.WEST, up, 0, SpringLayout.WEST, right);
        Right_layout.putConstraint(SpringLayout.SOUTH, up, -400, SpringLayout.SOUTH, right);
        Right_layout.putConstraint(SpringLayout.NORTH, button_command, 0, SpringLayout.SOUTH, up);
        Right_layout.putConstraint(SpringLayout.EAST, button_command, 0, SpringLayout.EAST, right);
        Right_layout.putConstraint(SpringLayout.WEST, button_command, 0, SpringLayout.WEST, right);
        Right_layout.putConstraint(SpringLayout.SOUTH, button_command, -300, SpringLayout.SOUTH, right);
        Right_layout.putConstraint(SpringLayout.NORTH, history.history_panel, 260, SpringLayout.NORTH, right);
        Right_layout.putConstraint(SpringLayout.EAST, history.history_panel, 0, SpringLayout.EAST, right);
        Right_layout.putConstraint(SpringLayout.WEST, history.history_panel, 0, SpringLayout.WEST, right);
        Right_layout.putConstraint(SpringLayout.SOUTH, history.history_panel, 0, SpringLayout.SOUTH, right);
        right.setLayout(Right_layout);

        Main_Chess_Window.setVisible(true);
    }

}
