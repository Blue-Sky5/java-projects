package chess;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Board_UI {
    int[][] temp_board;
    public JPanel main_panel;
    public tiles[][] board_tiles;
    Icon icon = null;
    public static AIPlayer ai = new AIPlayer();
    public chess_history game_history;
    public Board_UI(){
        this.main_panel = new JPanel();
        main_panel.setBounds(0,0,600,560);
        board_builder();
        piece_setter();
        Action_Listeners();
    }
    public void board_builder(){
        GridLayout Board_ui_layout = new GridLayout(8, 8);
        this.main_panel.setLayout(Board_ui_layout);
        this.board_tiles = new tiles[8][8];
        Icon icon = null;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++){
                board_tiles[i][j] = new tiles();
                board_tiles[i][j].x_cord = i;
                board_tiles[i][j].y_cord = j;
                board_tiles[i][j].setPreferredSize(new Dimension(40, 40));
                if (i % 2 == 0) {
                    if (j % 2 == 0) {
                        board_tiles[i][j].setBackground(new Color(204, 213, 174));
                    }
                    else {
                        board_tiles[i][j].setBackground(new Color(233, 231, 207));
                    }
                }
                else {
                    if (j % 2 == 0) {
                        board_tiles[i][j].setBackground(new Color(233, 231, 207));
                    } else {
                        board_tiles[i][j].setBackground(new Color(204, 213, 174));
                    }
                }
                main_panel.add(board_tiles[i][j]);
            }
        }
    }
    public void piece_setter(){
        Icon icon ;
        for (int i = 0 ; i < 8 ; i++){
            for (int j = 0 ; j<8 ; j++){
                switch (chess_array.chess_array[i][j]) {
                    case 6 -> board_tiles[i][j].piece = new pawn(6);
                    case 5 -> board_tiles[i][j].piece = new knight(5);
                    case 4 -> board_tiles[i][j].piece = new bishop(4);
                    case 3 -> board_tiles[i][j].piece = new rook(3);
                    case 2 -> board_tiles[i][j].piece = new queen(2);
                    case 1 -> board_tiles[i][j].piece = new king(1);
                    case -6 -> board_tiles[i][j].piece = new pawn(-6);
                    case -5 -> board_tiles[i][j].piece = new knight(-5);
                    case -4 -> board_tiles[i][j].piece = new bishop(-4);
                    case -3 -> board_tiles[i][j].piece = new rook(-3);
                    case -2 -> board_tiles[i][j].piece = new queen(-2);
                    case -1 -> board_tiles[i][j].piece = new king(-1);
                    default -> {
                        board_tiles[i][j].piece = null;
                    }
                }
                if(board_tiles[i][j].piece != null){
                    board_tiles[i][j].setIcon(new ImageIcon(board_tiles[i][j].piece.getIcon_address()));
                }
                else {
                    board_tiles[i][j].setIcon(null);
                }

            }
        }
    }
    public void set_game_history(chess_history game_history){
        this.game_history = game_history;
    }
    public void Action_Listeners(){
        for (int i = 0 ; i<8;i++){
            for(int j = 0 ; j<8;j++){
                int i_i = i;
                int j_j = j;
                board_tiles[i][j].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        Operator.input(board_tiles[i_i][j_j].x_cord,board_tiles[i_i][j_j].y_cord,board_tiles,game_history);
                        if(!Operator.White_Turn && Operator.AI){
                            chess_array.Move(board_tiles);
                            chess_array.chess_array = ai.nextMove(chess_array.chess_array,false);
                            piece_setter();
                            Operator.White_Turn = true;
                        }
                    }
                });
            }
        }
    }
    public void board_restart(){
        chess_array.Restart_Board();
        piece_setter();
    }
    public boolean load_board(){
        boolean a =  chess_array.load();
        piece_setter();
        return a;
    }
}
