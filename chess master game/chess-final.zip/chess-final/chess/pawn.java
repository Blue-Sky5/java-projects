package chess;

public class pawn extends chess_piece{
    public pawn(int x){
        if(x>0){
            setValue(this.value);
            setIcon_address(icon_address_w);
        }
        else {
            this.value*=-1;
            setValue(this.value);
            setIcon_address(icon_address_b);
        }
    }

    @Override
    public boolean is_valid_move(int x1,int y1,int x2, int y2, tiles[][] board_game) {
        if(this.getValue() >0){
            if(x2+1 == x1 && y1 == y2){
                return board_game[x2][y2].piece == null ;
            }
            else if(x2+1 == x1 && (y1+1 == y2 || y1-1 == y2)){
                return (board_game[x2][y2].piece != null && board_game[x2][y2].piece.getValue()*board_game[x1][y1].piece.getValue() < 0);
            }
            else {
                return false;
            }
        }
        else{
            if(x2-1 == x1 && y1 == y2){
                return board_game[x2][y2].piece == null;
            }
            else if(x2-1 == x1 && (y1+1 == y2 || y1-1 == y2)){
                return (board_game[x2][y2].piece != null && board_game[x2][y2].piece.getValue()*board_game[x1][y1].piece.getValue() < 0);
            }
            else {
                return false;
            }
        }
    }

    public int value = 6;
    public static String icon_address_w = "src/chess/Pieces PNG/white_pawn.png";
    public static String icon_address_b = "src/chess/Pieces PNG/black_pawn.png";
    public String icon_address;
}
