package chess;
import java.lang.Math;

public class bishop extends chess_piece{
    public bishop(int x){
        if(x>0){
            setValue(this.value);
            setIcon_address(icon_address_w);
        }
        else {
            this.value*=-1;
            setValue(this.value);
            setIcon_address(icon_address_b);
        }
    }

    @Override
    public boolean is_valid_move(int x1, int y1, int x2, int y2, tiles[][] board_game) {
        boolean is_clean = true;
        if(x1!=x2 && (int)Math.abs(x2-x1)==(int)Math.abs(y2-y1)){
            if(x2> x1 && y2 > y1){
                while (x1< x2){
                    x1+=1;
                    y1+=1;
                    if(board_game[x1][y1].piece != null && board_game[x1][y1].piece.getValue()*this.getValue() > 0){
                        System.out.println("!!!");
                        is_clean = false;
                    }
                }
            }
            else if(x2 < x1 && y2 < y1){
                while (x2 < x1){
                    y1-=1;
                    x1-=1;
                    if(board_game[x1][y1].piece != null && board_game[x1][y1].piece.getValue()*this.getValue() > 0){
                        System.out.println("!!!");
                        is_clean = false;
                    }
                }
            }
            else if(x2> x1 && y2 < y1){
                while (x2 > x1){
                    y1-=1;
                    x1+=1;
                    if(board_game[x1][y1].piece != null && board_game[x1][y1].piece.getValue()*this.getValue() > 0){
                        System.out.println("!!!");
                        is_clean = false;
                    }
                }
            }
            else {
                while (x2 < x1){
                    y1+=1;
                    x1-=1;
                    if(board_game[x1][y1].piece != null && board_game[x1][y1].piece.getValue()*this.getValue() > 0){
                        System.out.println("!!!");
                        is_clean = false;
                    }
                }
            }
            return is_clean;
        }
        else {
            return false;
        }
    }
    public static boolean is_valid_move_s(int x1, int y1, int x2, int y2, tiles[][] board_game) {
        int x11 = x1;
        int y11 = y1;
        boolean is_clean = true;
        if(x1!=x2 && (int)Math.abs(x2-x1)==(int)Math.abs(y2-y1)){
            if(x2> x1 && y2 > y1){
                while (x1< x2){
                    x1+=1;
                    y1+=1;
                    if(board_game[x1][y1].piece != null && board_game[x1][y1].piece.getValue()*board_game[x11][y11].piece.getValue() > 0){
                        System.out.println("!!!");
                        is_clean = false;
                    }
                }
            }
            else if(x2 < x1 && y2 < y1){
                while (x2 < x1){
                    y1-=1;
                    x1-=1;
                    if(board_game[x1][y1].piece != null && board_game[x1][y1].piece.getValue()*board_game[x11][y11].piece.getValue() > 0){
                        System.out.println("!!!");
                        is_clean = false;
                    }
                }
            }
            else if(x2> x1 && y2 < y1){
                while (x2 > x1){
                    y1-=1;
                    x1+=1;
                    if(board_game[x1][y1].piece != null && board_game[x1][y1].piece.getValue()*board_game[x11][y11].piece.getValue() > 0){
                        System.out.println("!!!");
                        is_clean = false;
                    }
                }
            }
            else {
                while (x2 < x1){
                    y1+=1;
                    x1-=1;
                    if(board_game[x1][y1].piece != null && board_game[x1][y1].piece.getValue()*board_game[x11][y11].piece.getValue() > 0){
                        System.out.println("!!!");
                        is_clean = false;
                    }
                }
            }
            return is_clean;
        }
        else {
            return false;
        }
    }
    public int value = 4;
    public static String icon_address_w = "src/chess/Pieces PNG/white_bishop.png";
    public static String icon_address_b = "src/chess/Pieces PNG/black_bishop.png";
    public static String icon_address ;
}
