package chess;

import javax.swing.*;
import java.awt.*;

public class chess_history {
    public JPanel history_panel;
    public JTextArea game_history;
    JScrollPane scroll;
    public chess_history(){
        history_panel = new JPanel(new FlowLayout());
        history_panel.setBackground(Color.lightGray);
        game_history = new JTextArea();
        history_panel.add(game_history);
        game_history.setEditable(false);
        game_history.setBackground(Color.lightGray);
        //scroll = new JScrollPane (game_history);
        game_history.append("GameHistory---------------------------------------------------\n| Begin:\n");
    }
    public void add(int value,int x1,int y1,int x2,int y2){
        String[] pattern = {"Queen","King","Rook","Bishop","Knight","Pawn"};
        String input = "| ";
        String Colour = "Black ";
        String alphabet = "ABCDEFGH";
        if(value >0){
            Colour = "White ";
        }
        input = input + Colour;
        //System.out.println(Math.abs(v));
        input+=pattern[Math.abs(value) - 1];
        input+=" : ";
        input+=alphabet.charAt(y1);
        input = input+""+(8-x1)+" ";
        input+="to ";
        input+=alphabet.charAt(y2);
        input = input+""+(8-x2)+"\n";
        this.game_history.append(input);
    }
    public void add2(String a , boolean is_white){
        String colour = "Black ";
        String input = "# ";
        if (is_white){
            colour = "White ";
        }
        input+=colour;
        input = input+a+" ";
        input+="Defeated\n";
        this.game_history.append(input);
    }
    public void restart(){
        this.game_history.setText(null);
        this.game_history.append("GameHistory---------------------------------------------------\n| Begin:\n");
    }
}
